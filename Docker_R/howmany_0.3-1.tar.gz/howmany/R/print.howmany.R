"print.howmany" <-
function(x,...)
  {
    summary(x)   
  }

