# Acknowledgements

This library has been made possible by the support and work of a lot of people and organizations. I feel a lot of gratitude towards them and would like to thank them this way:
* Prof. Melanie Börries [IBSM Freiburg](https://www.uniklinik-freiburg.de/institut-fuer-medizinische-bioinformatik-und-systemmedizin/englisch/en.html)
* Prof. Christian Rosenmund [Charite](http://www.rosenmundlab.de/)
* Dr. Alejandra Recalde for creating the Logo and the cunndata layout
* Taurean Dyer
* Corey Nolet
* The [RAPIDS](https://rapids.ai/) team
* The [CuPy](https://cupy.dev/) team
* The whole [scverse](https://scverse.org/) team
