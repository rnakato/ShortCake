from __future__ import annotations

from .squidpy_gpu import *
