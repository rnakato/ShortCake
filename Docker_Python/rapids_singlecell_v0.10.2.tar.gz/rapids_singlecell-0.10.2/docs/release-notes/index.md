(release-notes)=

# Release notes

## Version 0.10.0
```{include} /release-notes/0.10.2.md
``````
```{include} /release-notes/0.10.1.md
``````
```{include} /release-notes/0.10.0.md
``````

## Version 0.9.0
```{include} /release-notes/0.9.6.md
``````

```{include} /release-notes/0.9.5.md
``````

```{include} /release-notes/0.9.4.md
``````

```{include} /release-notes/0.9.3.md
``````

```{include} /release-notes/0.9.2.md
``````

```{include} /release-notes/0.9.1.md
``````

```{include} /release-notes/0.9.0.md
```

## Version 0.8.0

```{include} /release-notes/0.8.1.md
```
```{include} /release-notes/0.8.0.md
```
