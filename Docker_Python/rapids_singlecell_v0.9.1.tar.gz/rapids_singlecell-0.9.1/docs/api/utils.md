# Utils

These functions offer convineant ways to move arrays and matrices from and to the GPU.

```{eval-rst}
.. module:: rapids_singlecell.utils
.. currentmodule:: rapids_singlecell

.. autosummary::
    :toctree: generated

    utils.anndata_to_GPU
    utils.anndata_to_CPU
```
