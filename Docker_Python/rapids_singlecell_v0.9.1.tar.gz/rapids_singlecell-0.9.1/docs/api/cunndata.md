# cunnData

{class}`~rapids_singlecell.cunnData.cunnData` is deprecated and will be removed in 2024. Please start switching to {class}`~anndata.AnnData`

```{eval-rst}
.. module:: rapids_singlecell.cunnData
.. currentmodule:: rapids_singlecell

.. autosummary::
    :toctree: generated

    cunnData.cunnData
```
