# API

Import rapids-singlecell as:

```
import rapids_singlecell as rsc
```


```{toctree}
:maxdepth: 2

scanpy_gpu
squidpy_gpu
decoupler_gpu
utils
cunndata
```
