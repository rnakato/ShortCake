Notebooks
==========

Sample notebooks

.. toctree::
   :maxdepth: 1

   notebooks/demo_gpu
   notebooks/demo_gpu-seuratv3
   notebooks/demo_gpu-PR
   notebooks/demo_gpu-seuratv3-brain-1M
   notebooks/autocorr_benchmark
   notebooks/ligrec_benchmark
