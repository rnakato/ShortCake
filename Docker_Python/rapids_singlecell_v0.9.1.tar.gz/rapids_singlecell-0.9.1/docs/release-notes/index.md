(release-notes)=

# Release notes

## Version 0.9.0
```{include} /release-notes/0.9.1.md
``````

```{include} /release-notes/0.9.0.md
```

## Version 0.8.0

```{include} /release-notes/0.8.1.md
```
```{include} /release-notes/0.8.0.md
```
